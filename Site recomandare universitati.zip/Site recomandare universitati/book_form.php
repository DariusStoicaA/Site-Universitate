<?php

   $connection = mysqli_connect('localhost','root','','book_db');

   if(isset($_POST['send'])){
      $nume = $_POST['nume'];
      $email = $_POST['email'];
      $numar_telefon = $_POST['numar_telefon'];
      $adresa = $_POST['adresa'];
      $universitate = $_POST['universitate'];
      $studii = $_POST['studii'];
      $data_nasterii = $_POST['data_nasterii'];
      $absolvirea = $_POST['absolvirea'];

      $request = " insert into book_form(nume, email, numar_telefon, adresa, universitate, studii, data_nasterii, absolvirea) values('$nume','$email','$numar_telefon','$adresa','$universitate','$studii','$data_nasterii','$absolvirea') ";
      mysqli_query($connection, $request);

      header('location:book.php'); 

   }else{
      echo 'something went wrong please try again!';
   }

?>